import React, { useRef, useEffect } from 'react';

interface VideoPlayerProps {
  src: string;
  isPlaying: boolean;
  isMuted: boolean;
  onError: (error: string) => void;
}

export function VideoPlayer({ src, isPlaying, isMuted, onError }: VideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    if (isPlaying) {
      video.play().catch((error) => {
        onError('Failed to play video: ' + error.message);
      });
    } else {
      video.pause();
    }
  }, [isPlaying, onError]);

  return (
    <video
      ref={videoRef}
      className="absolute inset-0 w-full h-full object-cover"
      src={src}
      loop
      muted={isMuted}
      onError={() => onError('Failed to load video')}
      playsInline // Required for mobile devices
      preload="auto" // Ensure video is preloaded
      autoPlay={false} // Let us control playback manually
    >
      <source src={src} type="video/mp4" />
      Your browser does not support the video tag.
    </video>
  );
}