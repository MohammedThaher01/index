import React from 'react';
import { Play, Pause, Volume2, VolumeX, RefreshCcw, Download, ChevronLeft, ChevronRight } from 'lucide-react';

interface ControlsProps {
  isPlaying: boolean;
  isMuted: boolean;
  onPlayPause: () => void;
  onMuteToggle: () => void;
  onBackgroundChange: () => void;
  onDownload: () => void;
  onPreviousPart: () => void;
  onNextPart: () => void;
  canGoPrevious: boolean;
  canGoNext: boolean;
}

export function Controls({
  isPlaying,
  isMuted,
  onPlayPause,
  onMuteToggle,
  onBackgroundChange,
  onDownload,
  onPreviousPart,
  onNextPart,
  canGoPrevious,
  canGoNext,
}: ControlsProps) {
  return (
    <div className="space-y-4">
      <div className="flex gap-4 justify-center">
        <button
          onClick={onPreviousPart}
          disabled={!canGoPrevious}
          className={`flex items-center gap-2 px-4 py-3 rounded-lg transition-colors ${
            canGoPrevious ? 'bg-gray-700 hover:bg-gray-600' : 'bg-gray-800 cursor-not-allowed'
          }`}
        >
          <ChevronLeft className="w-5 h-5" />
        </button>

        <button
          onClick={onPlayPause}
          className="flex items-center gap-2 px-6 py-3 bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors"
        >
          {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
          {isPlaying ? 'Pause' : 'Play'}
        </button>
        
        <button
          onClick={onMuteToggle}
          className="flex items-center gap-2 px-6 py-3 bg-gray-700 rounded-lg hover:bg-gray-600 transition-colors"
        >
          {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
        </button>
        
        <button
          onClick={onBackgroundChange}
          className="flex items-center gap-2 px-6 py-3 bg-gray-700 rounded-lg hover:bg-gray-600 transition-colors"
        >
          <RefreshCcw className="w-5 h-5" />
        </button>

        <button
          onClick={onNextPart}
          disabled={!canGoNext}
          className={`flex items-center gap-2 px-4 py-3 rounded-lg transition-colors ${
            canGoNext ? 'bg-gray-700 hover:bg-gray-600' : 'bg-gray-800 cursor-not-allowed'
          }`}
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>
      
      <button
        onClick={onDownload}
        className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-green-600 rounded-lg hover:bg-green-700 transition-colors"
      >
        <Download className="w-5 h-5" />
        Download Video
      </button>
    </div>
  );
}</content>