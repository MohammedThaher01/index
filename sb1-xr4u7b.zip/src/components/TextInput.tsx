import React from 'react';
import { getWordCount, getEstimatedDuration } from '../utils/textUtils';

interface TextInputProps {
  value: string;
  onChange: (value: string) => void;
  currentPart: number;
  totalParts: number;
}

export function TextInput({ value, onChange, currentPart, totalParts }: TextInputProps) {
  const wordCount = getWordCount(value);
  const duration = getEstimatedDuration(value);
  const isWithinLimit = duration <= 60;

  return (
    <div className="space-y-2">
      <div className="flex justify-between text-sm text-gray-400">
        <span>Part {currentPart} of {totalParts}</span>
        <span className={isWithinLimit ? 'text-gray-400' : 'text-red-400'}>
          {wordCount} words (~{duration}s)
        </span>
      </div>
      <textarea
        className="w-full h-40 p-4 rounded-lg bg-gray-800 text-white resize-none focus:ring-2 focus:ring-blue-500 focus:outline-none"
        placeholder="Enter your text here..."
        value={value}
        onChange={(e) => onChange(e.target.value)}
      />
      {!isWithinLimit && (
        <p className="text-red-400 text-sm">
          Text is too long for a YouTube Short. Consider splitting into multiple parts.
        </p>
      )}
    </div>
  );
}