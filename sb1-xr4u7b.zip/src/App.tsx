import React, { useState, useEffect } from 'react';
import { VideoPlayer } from './components/VideoPlayer';
import { Controls } from './components/Controls';
import { TextInput } from './components/TextInput';
import { useSpeechSynthesis } from './hooks/useSpeechSynthesis';
import { splitTextIntoParts } from './utils/textUtils';

// Using direct CDN links to ensure video playback
const BACKGROUND_VIDEOS = [
  'https://assets.mixkit.co/videos/preview/mixkit-waves-in-the-water-1164-large.mp4',
  'https://assets.mixkit.co/videos/preview/mixkit-stars-in-space-1610-large.mp4',
  'https://assets.mixkit.co/videos/preview/mixkit-sunset-over-a-lake-1689-large.mp4'
];

function App() {
  const [fullText, setFullText] = useState('');
  const [textParts, setTextParts] = useState<string[]>([]);
  const [currentPartIndex, setCurrentPartIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [currentVideoIndex, setCurrentVideoIndex] = useState(0);
  const [error, setError] = useState<string | null>(null);
  
  const speech = useSpeechSynthesis();

  useEffect(() => {
    const parts = splitTextIntoParts(fullText);
    setTextParts(parts);
  }, [fullText]);

  const handleTextChange = (newText: string) => {
    setFullText(newText);
    setIsPlaying(false);
    speech.stop();
  };

  const handlePlay = () => {
    const currentText = textParts[currentPartIndex];
    if (!currentText?.trim()) {
      setError('Please enter some text before playing');
      return;
    }
    
    if (isPlaying) {
      speech.pause();
    } else {
      speech.speak(currentText);
    }
    setIsPlaying(!isPlaying);
    setError(null);
  };

  const handleBackgroundChange = () => {
    setCurrentVideoIndex((prev) => (prev + 1) % BACKGROUND_VIDEOS.length);
    setError(null);
  };

  const handleDownload = () => {
    alert('In a production environment, this would download the composed video with voice-over.');
  };

  const handleVideoError = (errorMessage: string) => {
    setError(`Video loading error. Try changing the background video.`);
    setIsPlaying(false);
    speech.stop();
  };

  const handlePreviousPart = () => {
    if (currentPartIndex > 0) {
      setCurrentPartIndex(prev => prev - 1);
      setIsPlaying(false);
      speech.stop();
    }
  };

  const handleNextPart = () => {
    if (currentPartIndex < textParts.length - 1) {
      setCurrentPartIndex(prev => prev + 1);
      setIsPlaying(false);
      speech.stop();
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-6">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-8 text-center">YouTube Shorts Generator</h1>
        
        {error && (
          <div className="mb-4 p-4 bg-red-500/20 border border-red-500 rounded-lg text-red-200">
            {error}
          </div>
        )}
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-4">
            <TextInput 
              value={fullText}
              onChange={handleTextChange}
              currentPart={currentPartIndex + 1}
              totalParts={Math.max(1, textParts.length)}
            />
            <Controls
              isPlaying={isPlaying}
              isMuted={isMuted}
              onPlayPause={handlePlay}
              onMuteToggle={() => setIsMuted(!isMuted)}
              onBackgroundChange={handleBackgroundChange}
              onDownload={handleDownload}
              onPreviousPart={handlePreviousPart}
              onNextPart={handleNextPart}
              canGoPrevious={currentPartIndex > 0}
              canGoNext={currentPartIndex < textParts.length - 1}
            />
          </div>
          
          <div className="relative rounded-lg overflow-hidden bg-gray-800 aspect-[9/16]">
            <VideoPlayer
              key={currentVideoIndex}
              src={BACKGROUND_VIDEOS[currentVideoIndex]}
              isPlaying={isPlaying}
              isMuted={isMuted}
              onError={handleVideoError}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;