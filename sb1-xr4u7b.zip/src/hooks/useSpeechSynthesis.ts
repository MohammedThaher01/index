import { useState, useCallback } from 'react';

export function useSpeechSynthesis() {
  const [utterance, setUtterance] = useState<SpeechSynthesisUtterance | null>(null);
  const speechSynthesis = window.speechSynthesis;

  const speak = useCallback((text: string) => {
    if (utterance) {
      speechSynthesis.cancel();
    }
    const newUtterance = new SpeechSynthesisUtterance(text);
    setUtterance(newUtterance);
    speechSynthesis.speak(newUtterance);
  }, [utterance]);

  const pause = useCallback(() => {
    speechSynthesis.pause();
  }, []);

  const resume = useCallback(() => {
    speechSynthesis.resume();
  }, []);

  const stop = useCallback(() => {
    speechSynthesis.cancel();
    setUtterance(null);
  }, []);

  return { speak, pause, resume, stop };
}