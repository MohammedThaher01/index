export function splitTextIntoParts(text: string): string[] {
  // Average speaking rate is about 150 words per minute
  const WORDS_PER_MINUTE = 150;
  const MAX_DURATION = 60; // 60 seconds for Shorts
  const MAX_WORDS = Math.floor(WORDS_PER_MINUTE * (MAX_DURATION / 60));

  const words = text.trim().split(/\s+/);
  const parts: string[] = [];
  let currentPart: string[] = [];
  let currentWordCount = 0;

  words.forEach((word) => {
    if (currentWordCount >= MAX_WORDS) {
      parts.push(currentPart.join(' '));
      currentPart = [];
      currentWordCount = 0;
    }
    currentPart.push(word);
    currentWordCount++;
  });

  if (currentPart.length > 0) {
    parts.push(currentPart.join(' '));
  }

  return parts;
}

export function getWordCount(text: string): number {
  return text.trim().split(/\s+/).filter(word => word.length > 0).length;
}

export function getEstimatedDuration(text: string): number {
  const WORDS_PER_MINUTE = 150;
  const wordCount = getWordCount(text);
  return Math.ceil((wordCount / WORDS_PER_MINUTE) * 60);
}